 kl <- read.table("kl_dat_con", header=FALSE, sep="\t")
 kl.names <- c("ldruck","ldruck","ldruck","ldruck_mitt","temp_luft_2m_max_d","temp_luft_2m_min_d","temp_luft_2m_diff_d","temp_luft_boden_min","temp_luft_2m", "temp_luft_2m","temp_luft_2m","temp_luft_mitt_d","temp_feucht","temp_feucht","temp_feucht","ddruck","ddruck","ddruck", "ddruck_mitt","feuchte_rel","feuchte_rel","feuchte_rel","feuchte_rel_mitt","feuchte_rel_reg", "feuchte_rel_reg","feuchte_rel_reg","wind_ri","wind_stae","wind_ri","wind_Stae","wind_ri","wind_stae","wind_stae_mitt", "wolken_bed","wolken_di","wetter","wolken_bed","wolken_di","wetter","wolken_bed", "wolken_di","wetter","wolken_bed_d_mitt","sonn_dauer_sum_gem","sonn_schein_kenn","sichtw","sichtw","sichtw","boden_zust","boden_zust", "boden_zust","n_art_24h","n_art_abgesetzt","wetter_kenn","n_hoehe_sum","n_form", "n_hoehe_sum","n_form","n_hoehe_sum","n_form","n_24h","n_art_24h","schnee_h", "schnee_h_neu","schnee_kenn_neu","wind_v_d_max","schnee_ash","schnee_waas","schnee_wash")
 columns <- c("1-2","3-7","8-11","12-13","14-15","16-19","20-24","25","26-30","31","32-36","37","38-42","43","44-47","48","49-52","53","54-56","57","58-61","62","63","64-67","68","69-72","73","74-77","78","79-82","83","84-87","88","89","90-93","94","95","96-99","100","101","102-104","105","106-108","109","110-112","113","114-116","117","118-120","121","122-124","125","126-128","129","130-132","133","134-136","137") 
columns <- c(columns,"138-140","141","142-144","145","146-147","148-149","150","151-152","153-154","155","156-157","158-159","160","161-163","164","165-166","167","168-169","170","171-172","173","174-175","176","177-178","179","180-181","182","183-184","185","186-187","188","189-190","191","192-194","195","196-198","199","200","201-202","203","204-205","206","207-208","209","210-211","212","213-214","215","216-217","218","219-220","221","222-223","224","225-226","227","228-231","232","233","234-237","238","239","240-243","244","245","246-249","250","251","252-254","255","256","257-259","260","261","262-264","265","266-269","270","271-275","276","277-281","282")

 kl.times <- c("0600","1200","1800","2300","+24h","+24h","+24h","+24h","0600", "1200","1800","+24h","0600","1200","1800","0600","1200","1800", "+24h","0600","1200","1800","2300","0600", "1200","1800","0600","0600","1200","1200","1800","1800","2300", "0600","0600","0600","1200","1200","1200","1800", "1800","1800","2300","+24h","+24h","0600","1200","1800","0600","1200", "1800","+24h","+24h","+24h","0600","0600", "1200","1200","1800","1800","+24h","+24h","0600", "0600","0600","+24h","0600","0600","0730")

 kl.names.ind <- c(3,5,7,9,11,13,15,17,20, 22,24,26,28,31,34,37,39,41, 43,45,47,49,51,53, 55,57,59,60,62,63,65,66,68, 70,72,74,76,78,80,82, 84,86,88,90,91,93,95,97,99,101, 103,105,107,109,111,112, 114,115,117,118,120,121,123, 126,127,129,131,133,135) + 4
 na_val <- c(-9999,-9999,-9999,-9999,-999,-999,-99,-999,-999, -999,-999,-999,-999,-999,-999,-99,-99,-99, -99,-99,-99,-99,-99,-99, -99,-99,-9,-9,-9,-9,-9,-9,-99, -9,-9,-9,-9,-9,-9,-9, -9,-9,-99,-99,9,-9,-9,-9,-9,-9, -9,-9,-9,-9,-999,9, -999,9,-999,9,-999,9,-99, -99,9,-99,-999,-9999,-9999)
 factors <- c(0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1, 0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1, 0.1,1,1,1,1,1, 1,1,1,1,1,1,1,1,1, 1,1,1,1,1,1,1, 1,1,0.1,0.1,1,1,1,1,1,1, 1,1,1,1,0.1,1, 0.1,1,0.1,1,0.1,1,1, 1,1,0.1,1,0.1,0.1)
 
 for(index in 1:length(kl.names.ind)){
      kl[,kl.names.ind[index]] [kl[,kl.names.ind[index]] == na_val[index]] <- NA
      if(!class(kl[,kl.names.ind[index]]) %in% c("numeric", "logical", "integer")) stop(paste("index", index, "is not numeric"))
      kl[,kl.names.ind[index]] <- kl[,kl.names.ind[index]] * factors[index]
 }
 kl.qbytes.ind <- c(4,6,8,10,12,14,16,19,21, 23,25,27,30,33,36,38,40,42, 44,46,48,50,52,54, 56,58,61,61,64,64,67,67,69, 71,73,75,77,79,81,83, 85,87,89,92,92,94,96,98,100,102, 104,106,108,110,113,113, 116,116,119,119,122,122,125, 128,128,130,132,134,136) + 4
  names(kl)[1:5] <- c("type", "stationID", "Year", "Month", "Day") 
  names(kl)[kl.names.ind] <- paste(kl.names, kl.times, sep="_")
  names(kl)[kl.qbytes.ind] <- paste("QByte",kl.names, kl.times, sep="_")
  date <- strptime(paste(kl[,3],kl[,4],kl[,5],sep="-"), "%Y-%m-%d")
  library(zoo)
  kl.zoo <- list()
  stations<-data.frame(id=c(3237, 3386, 3394, 4135, 4137, 4144, 4149, 4151, 4152, 4404,4414),
             name=c("DRESDEN-STREHLEN","DRESDEN-KLOTZ","DRESDEN-HOSTERWITZ","MEMMINGEN","KEMPTEN","OBERSTDORF","KAUFBEUREN","SCHWANGAU-HORN","OY-MITTELBERG-PETERSTHAL","DIPPOLDISWALDE-REINBERG","ZINNWALD-GEORGEN"),stringsAsFactors=FALSE)
  for(station in unique(kl[,2])){
       is.station.data <- kl[,2] == station
       stat.name <- stations$name[stations$id == station]
       kl.zoo[[stat.name]] <- zoo(kl[is.station.data,], order.by=as.POSIXct(date)[is.station.data])
  }
  save(kl.zoo, file="kl.rda")
