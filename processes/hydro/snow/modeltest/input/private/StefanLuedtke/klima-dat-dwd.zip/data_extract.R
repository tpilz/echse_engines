rm(list=ls())
library(zoo)

## load dataset --> zoo object
load("kl.rda")

##define vector with indices of required stations
station_index=c(1,2,3,10,11)
##get length of timeseries
time_l=nrow(data.frame(kl.zoo[1]))

##define array to write data into

#temperature
a_temp=array(data=NA, dim=c(time_l,length(station_index)))
p_temp=array(data=NA, dim=c(time_l,length(station_index)))
w_temp=array(data=NA, dim=c(time_l,length(station_index)))
sh_temp=array(data=NA, dim=c(time_l,length(station_index)))
swe_temp=array(data=NA, dim=c(time_l,length(station_index)))
sh_zy=array(data=NA, dim=c(time_l,length(station_index)))
swe_zy=array(data=NA, dim=c(time_l,length(station_index)))
neuSchnee=array(data=NA, dim=c(time_l,length(station_index)))

k=1
for (i in station_index)
{
    temp=NULL
    temp=data.frame(coredata(kl.zoo[i]))

    a_temp[,k]=as.numeric(as.vector(temp[,30]))        #column with mean day temperature
    
    p_temp[,k]=as.numeric(as.vector(temp[,124]))       #column with precipitation from 7.30 till 7.30

    w_temp[,k]=as.numeric(as.vector(temp[,72]))       #column with  mean  windstrength till 11 pm

    sh_temp[,k]=as.numeric(as.vector(temp[,127]))/100

    swe_temp[,k]=as.numeric(as.vector(temp[,139]))

    sh_zy[,k]=as.numeric(as.vector(temp[,135]))/100
    
    swe_zy[,k]=as.numeric(as.vector(temp[,137]))
    
    neuSchnee[,k]=as.numeric(as.vector(temp[,131]))

    k=k+1
}

time_index=c(76,90,104,119,146)         # index of timeseries were snow was measured

sh_ges=sh_temp[185:365,5]
swe_ges=swe_temp[185:365,5]
sh_zy=sh_zy[185:365,5]
swe_zy=swe_zy[185:365,5]
time=c(1:181)
dens_ges=swe_ges/sh_ges
dens_zy=swe_zy/sh_zy


a_temp=zooreg(a_temp[185:365,], start=1)
p_temp=zooreg(p_temp[185:365,], start=1)
w_temp=zooreg(w_temp[185:365,], start=1)
neuSchnee=zooreg(neuSchnee[185:365,], start=1)
neuSchneeH=zooreg(neuSchneeH[185:365,], start=1)
sh_ges=zooreg(sh_ges, start=1)
swe_ges=zooreg(swe_ges, start=1)
sh_zy=zooreg(sh_zy, start=1)
swe_zy=zooreg(swe_zy, start=1)

#write.table(a_temp, "temp_0809.txt", sep="\t", eol="\n", row.names=TRUE, col.names=FALSE, quote=FALSE)
#write.table(p_temp, "prec_0809.txt", sep="\t", eol="\n", row.names=TRUE, col.names=FALSE, quote=FALSE)
#write.table(w_temp, "wind_0809.txt", sep="\t", eol="\n", row.names=TRUE, col.names=FALSE, quote=FALSE)

